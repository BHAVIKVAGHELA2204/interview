<div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
      <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
          <li class="nav-header">
            <div class="dropdown profile-element">
                <?php if($this->session->userdata('profile_image')!=''){ ?>
                  <img alt="image" width="50" class="rounded-circle" src="<?php echo base_url('documents/profile/'.$this->session->userdata('profile_image')); ?>"/>
                <?php }else{ ?>
                  <img alt="image" width="50" class="rounded-circle" src="<?php echo base_url('documents/profile/default.jpg'); ?>"/>
                <?php } ?>
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="block m-t-xs font-bold"><?php echo $this->session->userdata('name'); ?></span>
                    <span class="text-muted text-xs block"><?php echo $this->session->userdata('department_name'); ?> <b class="caret"></b></span>
                </a>
                <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <li><a class="dropdown-item" href="<?php echo base_url('profile') ?>">Profile</a></li>
                    <li class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="<?php echo base_url('login/logout'); ?>">Logout</a></li>
                </ul>
            </div>
            <div class="logo-element">
              IT
            </div>
          </li>
          <li>
            <a href="<?php echo base_url('home'); ?>">
              <i class="fa fa-home"></i> 
              <span class="nav-label">Home</span>
            </a>
          </li>
          <?php 
            $tickets=array_search('tickets', array_column($access, 'param'));
            if($access[$tickets]['can_create']==1 || $access[$tickets]['can_view']==1){ 
          ?>
          <li>
            <a href="#">
              <i class="fa fa-ticket"></i> 
              <span class="nav-label">Tickets</span>
              <span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level collapse">
              <?php if($access[$tickets]['can_create']==1){ ?>
                <li>
                  <a href="<?php echo base_url('tickets/add'); ?>">Add Ticket</a>
                </li>
              <?php } ?>
              <?php if($access[$tickets]['can_view']==1){ ?>
                <li>
                  <a href="<?php echo base_url('tickets'); ?>">All Ticket</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/assign_to_me'); ?>">Assigned to Me</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/my'); ?>">My Tickets</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/new_tickets'); ?>">New Tickets</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/open'); ?>">Open Tickets</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/hold'); ?>">On Hold Tickets</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/resolved'); ?>">Resolved Tickets</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/reopen'); ?>">Reopen Tickets</a>
                </li>
                <li>
                  <a href="<?php echo base_url('tickets/close'); ?>">Close Tickets</a>
                </li>
              <?php } ?>
            </ul>
          </li>
          <?php } ?>
          <li>
              <a href="#"><i class="fa fa-sitemap"></i> <span class="nav-label">Settings</span><span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                  <li>
                      <a href="#" id="damian">Tickets<span class="fa arrow"></span></a>
                      <ul class="nav nav-third-level">
                          <li>
                              <a href="<?php echo base_url('settings/ticket_priorities'); ?>">Priorities</a>
                          </li>
                          <li>
                              <a href="<?php echo base_url('settings/ticket_categories'); ?>">Categories</a>
                          </li>
                          <li>
                              <a href="<?php echo base_url('settings/service_items'); ?>">Service Items</a>
                          </li>
                      </ul>
                  </li>
                  <li>
                      <a href="#" id="damian">Email<span class="fa arrow"></span></a>
                      <ul class="nav nav-third-level">
                          <li>
                              <a href="<?php echo base_url('settings/email_template'); ?>">Email template</a>
                          </li>
                          <li>
                              <a href="<?php echo base_url('settings/email_tags'); ?>">Email tags</a>
                          </li>
                      </ul>
                  </li>
              </ul>

          </li>
          <?php 
            $solution=array_search('solution', array_column($access, 'param'));
            if($access[$solution]['can_create']==1 || $access[$solution]['can_view']==1){ 
          ?>
          <li>
            <a href="<?php echo base_url('solutions'); ?>">
              <i class="fa fa-lightbulb-o" aria-hidden="true"></i>
              <span class="nav-label">Solutions</span>
            </a>
          </li>
          <?php } ?>

          <?php 
            $reports=array_search('reports', array_column($access, 'param'));
            if($access[$reports]['can_create']==1 || $access[$reports]['can_view']==1){ 
          ?>
          <li>
            <a href="#"><i class="fa fa-bar-chart" aria-hidden="true"></i> <span class="nav-label">Reports</span><span class="fa arrow"></span></a>
            <ul class="nav nav-second-level collapse">
              <?php if($access[$reports]['can_view']==1){ ?>
                <li><a href="<?php echo base_url('reports/bymonth'); ?>">Tickets by month</a></li>
              <?php } ?>
              <?php if($access[$reports]['can_view']==1){ ?>
                <li><a href="<?php echo base_url('reports/bycategory'); ?>">Tickets by category</a></li>
              <?php } ?>
              <?php if($access[$reports]['can_view']==1){ ?>
                <li><a href="<?php echo base_url('reports/byagent'); ?>">Tickets by agent</a></li>
              <?php } ?>
            </ul>
          </li>
          <?php } ?>
          <?php
            $roles=array_search('roles', array_column($access, 'param'));
            $departments=array_search('departments', array_column($access, 'param')); 
            $users=array_search('users', array_column($access, 'param')); 
            if($access[$roles]['can_view']==1 || $access[$departments]['can_view']==1 || $access[$users]['can_view']==1){
           ?>
          <li>
            <a href="#"><i class="fa fa-list"></i> <span class="nav-label">IT</span><span class="fa arrow"></span></a>
            <ul class="nav nav-second-level collapse">
              <?php if($access[$roles]['can_view']==1){ ?>
                <li><a href="<?php echo base_url('roles'); ?>">Roles</a></li>
              <?php } ?>
              <?php if($access[$departments]['can_view']==1){ ?>
                <li><a href="<?php echo base_url('departments'); ?>">Departments</a></li>
              <?php } ?>
              <?php if($access[$users]['can_view']==1){ ?>
                <li><a href="<?php echo base_url('users'); ?>">Users</a></li>
              <?php } ?>
            </ul>
          </li>
          <?php } ?>
        </ul>
      </div>
    </nav>
    <?php $activity_head_logs = activity_notification_details(); ?>
    <div id="page-wrapper" class="gray-bg dashbard-1">
      <div class="row border-bottom">
          <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
              <li style="padding: 20px">
                <span class="m-r-sm text-muted welcome-message">Welcome to IT Support.</span>
              </li>
              <li class="dropdown">
                    <a class="dropdown-toggle count-info" data-toggle="dropdown" href="">
                      <i class="fa fa-bell-o"></i> 
                        <span class="label label-warning">
                          <?php echo count($activity_head_logs);?>
                        </span>
                    </a>
                    <ul class="dropdown-menu dropdown-messages dropdown-messages-pd dropdown-menu-right">
                      <?php if (empty($activity_head_logs)){ ?>
                        <div class="alert alert-warning no-margin-alert text-center">
                            <strong>Notification not found</strong>
                        </div>  
                      <?php } $i = 0;?>
                      <?php foreach ($activity_head_logs as $activity) { $i++;?>
                        <li>
                          <a class="dropdown-item notification-pd" href="<?php echo base_url();?>activitylog/read_activity/<?php echo $activity->action_id;?>/<?php echo $activity->activity_id; ?>">
                            <div class="dropdown-messages-box">
                              <?php if($activity->user_profile!=''){ ?>
                                <img src="<?php echo base_url();?>documents/profile/<?php echo $activity->user_profile;?>" class="rounded-circle float-left" alt="<?php echo $activity->user_name;?> ">
                              <?php }else{ ?>
                                <img src="<?php echo base_url();?>documents/profile/default.jpg" class="rounded-circle float-left" alt="<?php echo $activity->user_name;?> ">
                              <?php } ?>
                              <div class="media-body content-pd">
                                <strong>
                                  <?php echo $activity->user_name;?>                              
                                </strong> 
                                  <?php echo $activity->text; ?>. <br>
                                <small class="text-muted">
                                  <?php echo date('m/d/Y G:i:s', $activity->time) ?>
                                </small>
                              </div>
                            </div>
                          </a>
                        </li>
                        <li class="dropdown-divider"></li>
                        <?php if($i==10) break; } ?>
                        <li>
                          <div class="text-center link-block">
                            <a href="<?php echo base_url();?>activitylog" class="dropdown-item">
                              <strong>SEE ALL NOTIFICATIONS</strong>
                            </a>
                          </div>
                        </li>
                    </ul>
                </li>
              <li>
                <a href="<?php echo base_url('login/logout'); ?>">
                  <i class="fa fa-sign-out"></i> Log out
                </a>
              </li>
            </ul>
          </nav>
      </div>