<div class="footer">
  <div>
    <strong>Copyright</strong> &copy; <?php echo date('Y'); ?> Interview. All rights reserved.
  </div>
</div>