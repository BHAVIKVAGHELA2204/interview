<link rel="shortcut icon" href="<?php echo base_url('assets/img/favicon.png'); ?>" id="favicon">
  <link href="<?php echo base_url('assets/plugins/jquery-ui/jquery-ui.min.css'); ?>" rel="stylesheet" />
  <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/font-awesome/css/font-awesome.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/toastr/toastr.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/js/plugins/gritter/jquery.gritter.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/dataTables/datatables.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/summernote/summernote-bs4.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/select2/select2.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/datapicker/datepicker3.css');?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/dropzone/basic.css');?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/dropzone/dropzone.css');?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/plugins/codemirror/codemirror.css');?>" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/css/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">

  <script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.validate.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/plugins/dataTables/datatables.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/plugins/dataTables/dataTables.bootstrap4.min.js'); ?>"></script>
  <!-- Data picker -->
  <script src="<?php echo base_url('assets/js/plugins/datapicker/bootstrap-datepicker.js');?>"></script>

  <script src="<?php echo base_url('assets/js/plugins/summernote/summernote-bs4.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/plugins/select2/select2.full.min.js'); ?>"></script>

  <script src="<?php echo base_url('assets/js/plugins/dropzone/dropzone.js');?>"></script>

   <link href="<?php echo base_url('assets/css/animate.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet">
  
  <link href="<?php echo base_url('assets/css/custom.css'); ?>" rel="stylesheet">
  <!-- Tags Input -->
    <script src="<?php echo base_url();?>assets/js/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>