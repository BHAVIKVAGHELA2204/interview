<script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>
<!-- Flot -->
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.tooltip.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.spline.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.resize.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.pie.js'); ?>"></script>
<!-- Peity -->
<script src="<?php echo base_url('assets/js/plugins/peity/jquery.peity.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/demo/peity-demo.js'); ?>"></script>
<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('assets/js/inspinia.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js'); ?>"></script>
<!-- jQuery UI -->
<script src="<?php echo base_url('assets/js/plugins/jquery-ui/jquery-ui.min.js'); ?>"></script>
<!-- GITTER -->
<script src="<?php echo base_url('assets/js/plugins/gritter/jquery.gritter.min.js'); ?>"></script>
<!-- Sparkline -->
<script src="<?php echo base_url('assets/js/plugins/sparkline/jquery.sparkline.min.js'); ?>"></script>
<!-- Sparkline demo data  -->
<script src="<?php echo base_url('assets/js/demo/sparkline-demo.js'); ?>"></script>
<!-- ChartJS-->
<script src="<?php echo base_url('assets/js/plugins/chartJs/Chart.min.js'); ?>"></script>
<!-- Toastr -->
<script src="<?php echo base_url('assets/js/plugins/toastr/toastr.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/plugins/chartJs/Chart.min.js');?>"></script>
<!-- <script src="<?php // echo base_url('assets/js/demo/chartjs-demo.js');?>"></script> -->

<script src="<?php echo base_url('assets/js/plugins/codemirror/codemirror.js');?>"></script>
<script src="<?php echo base_url('assets/js/plugins/codemirror/mode/xml/xml.js');?>"></script>
  <script>
    $(document).ready(function() {
      var cur_link="<?php echo base_url().uri_string(); ?>";
      $(".sidebar-collapse a").each(function(){
        if($(this).attr('href')==cur_link){
          $(this).parents("li").addClass("active");
          $(this).closest('li').closest('ul.nav-second-level').addClass('collapse in');
          $(this).closest('li').closest('ul.nav-third-level').addClass('collapse in');
          $(this).closest('li').addClass('active');
        }
      });
      setTimeout(function() {
        toastr.options = {
          closeButton: true,
          progressBar: true,
          showMethod: 'slideDown',
          timeOut: 4000
        };
        <?php if($this->session->flashdata('success')!=null){ ?>
          toastr.success('Success', "<?php echo $this->session->flashdata('success'); ?>");
        <?php } ?>
        <?php if($this->session->flashdata('error')!=null){ ?>
          toastr.error('Error', "<?php echo $this->session->flashdata('error'); ?>");
        <?php } ?>
        <?php if($this->session->flashdata('welcome')!=null){ ?>
          toastr.info('Welcome', "<?php echo $this->session->flashdata('welcome'); ?>");
        <?php } ?>
      }, 1300);
    });
  </script>