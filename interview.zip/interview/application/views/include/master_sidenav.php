<nav class="navbar-default navbar-static-side" role="navigation">
      <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
          <li class="nav-header">
            <div class="dropdown profile-element text-center">
                <?php if($this->session->userdata('profile_image')!=''){ ?>
                  <img alt="image" width="50" height="50" class="rounded-circle" src="<?php echo base_url('documents/profile/'.$this->session->userdata('profile_image')); ?>"/>
                <?php }else{ ?>
                  <img alt="image" width="50" height="50" class="rounded-circle" src="<?php echo base_url('documents/profile/default.jpg'); ?>"/>
                <?php } ?>
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="block m-t-xs font-bold"><?php echo $this->session->userdata('name'); ?></span>
                    <span class="text-muted text-xs block"><?php echo $this->session->userdata('department_name'); ?> <b class="caret"></b></span>
                </a>
                <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <li><a class="dropdown-item" href="<?php echo base_url('login/logout'); ?>">Logout</a></li>
                </ul>
            </div>
            <div class="logo-element">
              IW
            </div>
          </li>
          <li>
            <a href="<?php echo base_url('home'); ?>">
              <i class="fa fa-home"></i> 
              <span class="nav-label">Home</span>
            </a>
          </li>
          <li>
            <a href="<?php echo base_url('product'); ?>">
              <i class="fa fa-lightbulb-o"></i> 
              <span class="nav-label">Product</span>
            </a>
          </li>
    
        </ul>
      </div>
    </nav>