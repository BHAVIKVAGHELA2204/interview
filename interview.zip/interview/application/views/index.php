<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Dashboard</title>
  <?php $this->load->view('include/master_css');?>
</head>
<body class="font-black-color">
  <div id="wrapper">
    <?php $this->load->view('include/master_sidenav');?>
    <div id="page-wrapper" class="gray-bg dashbard-1">
      <?php $this->load->view('include/master_topnav');?>
        <div class="row wrapper border-bottom white-bg page-heading">
          <div class="col-lg-10">
              <h2><?php echo $this->session->userdata('name'); ?></h2>
              <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                      <a href="<?php echo base_url(); ?>">Home</a>
                  </li>
                  <li class="breadcrumb-item active">
                      <strong>Profile</strong>
                  </li>
              </ol>
          </div>
          <div class="col-lg-2">

          </div>
        </div>
        <div class="wrapper wrapper-content  animated fadeInRight">
          <div class="tabs-container">
            <ul class="nav nav-tabs" role="tablist">
              <li><a class="nav-link active" data-toggle="tab" href="#profile-detail">Profile Detail</a></li>
              <li><a class="nav-link" data-toggle="tab" href="#change-password">Change Password</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" id="profile-detail" class="tab-pane active">
                <div class="panel-body">
                    <form method="post" action="<?php echo base_url('profile/update_profile'); ?>" enctype="multipart/form-data" id="profile_form">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="card">
                                  <?php if($this->session->userdata('profile_image')!=''){ ?>
                                    <img class="card-img-top" src="<?php echo base_url('documents/profile/').$this->session->userdata('profile_image'); ?>" alt="<?php echo $this->session->userdata('name'); ?>">
                                  <?php }else{ ?>
                                    <img class="card-img-top" src="<?php echo base_url('documents/profile/default.jpg'); ?>" alt="<?php echo $this->session->userdata('name'); ?>">
                                  <?php } ?>
                                  <div class="card-body">
                                    <div class="card-text">
                                        <table class="table">
                                            <thead>
                                                <th style="width:10%;"><i class="fa fa-user"></i></th>
                                                <th><?php echo $this->session->userdata('name'); ?></th>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td style="width:10%;"><i class="fa fa-phone"></i></td>
                                                    <td><?php echo $this->session->userdata('phone'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width:10%;"><i class="fa fa-envelope"></i></td>
                                                    <td><?php echo $this->session->userdata('email'); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                  </div>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                  <input type="hidden" class="form-control" name="profile_id" id="profile_id" value="<?php echo $this->session->userdata('id'); ?>">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="name" id="name" value="<?php echo $this->session->userdata('name'); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Username</label>
                                    <input type="text" class="form-control" name="username" id="username" value="<?php echo $this->session->userdata('username'); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control" name="email" id="email" value="<?php echo $this->session->userdata('email'); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input type="text" class="form-control" name="phone" id="phone" value="<?php echo $this->session->userdata('phone'); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Profile Image</label>
                                    <div><input type="file" name="profile_image" id="profile_image"></div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Save Detail</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>  
              </div>
              <div role="tabpanel" id="change-password" class="tab-pane">
                <div class="panel-body">
                  <form method="post" action="<?php echo base_url('profile/change_password'); ?>" id="change_password_form">
                    <div class="form-group">
                      <label>Old Paswrod<sup class="text-danger">*</sup></label>
                      <input type="password" name="old_password" id="old_password" class="form-control">
                    </div>
                    <div class="form-group">
                      <label>New Paswrod<sup class="text-danger">*</sup></label>
                      <input type="password" name="new_password" id="new_password" class="form-control">
                    </div>
                    <div class="form-group">
                      <label>Confirm Paswrod<sup class="text-danger">*</sup></label>
                      <input type="password" name="confirm_password" id="confirm_password" class="form-control">
                    </div>
                    <button class="btn btn-primary" type="submit">Change Password</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php $this->load->view('include/master_footer')?>
    </div>
  </div>
  
<?php $this->load->view('include/master_js');?>

<script type="text/javascript">
$(document).ready(function(){
    $("#profile_form").validate ({
        rules: {
            name:{
                required : true,
            },
            username:{
                required : true,
            },
            email:{
                required : true,
                email:true,
            },
            department:{
                required:true,
            },
            phone:{
                required : true,
            }
        }, 
        highlight: function(element) {
          $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
        },
        success: function(element) {
          element.closest('.form-group').removeClass('has-error').addClass('has-success');
          $(element).closest('.error').remove();
        }
    });
    $("#change_password_form").validate ({
        rules: {
            old_password:{
                required : true,
            },
            new_password:{
                required : true,
                minlength : 5,
            },
            confirm_password:{
                required : true,
                equalTo:"#new_password",
            }
        }, 
        highlight: function(element) {
          $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
        },
        success: function(element) {
          element.closest('.form-group').removeClass('has-error').addClass('has-success');
          $(element).closest('.error').remove();
        }
    });
});
</script>
</body>
</html>