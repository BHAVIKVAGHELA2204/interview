<p>Change password.</p>
<form class="m-t login" role="form" action="<?php echo base_url('login/update_password'); ?>" method="post" id="change_password_form">
    <input type="hidden" name="forgot_key" id="forgot_key" value="<?php echo $forgot_key; ?>">
    <div class="form-group">
      <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-key gray-icon"></i></span>
          <input type="password" name="new_password" id="new_password" class="form-control" placeholder="New Password" required="">
      </div>
    </div>
    <div class="form-group">
      <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-key gray-icon"></i></span>
          <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Confirm Password" required="">
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-lg block full-width m-b" name="submit">Change Password</button>
</form>
<a href="<?php echo base_url(); ?>" class="btn btn-default btn-outline ">Back to login</a>
<script type="text/javascript">
    $(document).ready(function(){
        $("#change_password_form").validate ({
            rules: {
              new_password:{
                required : true,
                minlength : true,
              },
              confirm_password:{
                required : true,
                equalTo:"#new_password",
              },
            }, 
            highlight: function(element) {
              $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
            },
            success: function(element) {
              element.closest('.form-group').removeClass('has-error').addClass('has-success');
              $(element).closest('.error').remove();
            }
        });
    });
</script>