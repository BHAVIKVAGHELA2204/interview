
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Forgot Password</title>
    <?php  $this->load->view('include/login_master'); ?>
</head>

<body class="blue-bg">

    <div class="middle-box text-center loginscreen">
        <p>Recover your password.</p>
        <form class="m-t login" role="form" action="<?php echo base_url('login/check_forgot_password'); ?>" method="post" id="forgot_password_form">
            <div class="form-group">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope gray-icon"></i></span>
                    <input type="text" name="email" id="email" class="form-control" placeholder="Email" required="">
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-lg block full-width m-b" name="submit">Click Here</button>
        </form>
        <a href="<?php echo base_url(); ?>" class="btn btn-default btn-outline ">Back to login</a>
    </div>
    <script type="text/javascript">
    $(document).ready(function(){
        $("#forgot_password_form").validate ({
            rules: {
              email:{
                required : true,
                email : true,
              }
            }, 
            highlight: function(element) {
              $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
            },
            success: function(element) {
              element.closest('.form-group').removeClass('has-error').addClass('has-success');
              $(element).closest('.error').remove();
            }
        });
    });
</script>
</body>
</html>
