
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login</title>
    <?php  $this->load->view('include/login_master'); ?>
</head>

<body class="blue-bg">

    <div class="middle-box text-center loginscreen">
        <div>
          <div>
              <h2>Interview</h2><hr>
          </div>
            <form class="m-t login" role="form" action="<?php echo base_url('login'); ?>" method="post" id="login_form">
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon line-height-2"><i class="fa fa-user gray-icon"></i></span>
                        <input type="text" name="username" id="username" class="form-control" placeholder="Username" required="">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-group-addon line-height-2"><i class="fa fa-key gray-icon"></i></span>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Password" required="">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-lg block full-width m-b" name="submit">Login</button>
            </form>
            <a href="<?php echo base_url('forgot_password'); ?>" class="btn btn-default btn-outline ">Forgot Password</a>
            <a href="<?php echo base_url('signup'); ?>" class="btn btn-default btn-outline ">Sign-Up</a>
          <p class="m-t"> <small>Copyright &copy; <?php echo date('Y'); ?> Interview. All rights reserved.</small> </p>
        </div>
    </div>
    <script type="text/javascript">
	    $(document).ready(function(){
            setTimeout(function() {
                toastr.options = {
                  closeButton: true,
                  progressBar: true,
                  showMethod: 'slideDown',
                  timeOut: 4000
                };
                <?php if($this->session->flashdata('success')!=null){ ?>
                  toastr.success('Success', "<?php echo $this->session->flashdata('success'); ?>");
                <?php } ?>
                <?php if($this->session->flashdata('error')!=null){ ?>
                  toastr.error('Error', "<?php echo $this->session->flashdata('error'); ?>");
                <?php } ?>
                <?php if($this->session->flashdata('welcome')!=null){ ?>
                  toastr.info('Welcome', "<?php echo $this->session->flashdata('welcome'); ?>");
                <?php } ?>
              }, 1300);
	        $("#login_form").validate ({
	            rules: {
	              username:{
	                required : true,
	              },
	              password:{
	                required : true,
	              }
	            }, 
	            highlight: function(element) {
	              $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
	            },
	            success: function(element) {
	              element.closest('.form-group').removeClass('has-error').addClass('has-success');
	              $(element).closest('.error').remove();
	            }
	        });
	    });
	</script>
</body>
</html>
