<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Products</title>
  <?php $this->load->view('include/master_css');?>
</head>
<body class="font-black-color">
  <div id="wrapper">
    <?php $this->load->view('include/master_sidenav');?>
    <div id="page-wrapper" class="gray-bg dashbard-1">
      <?php $this->load->view('include/master_topnav');?>
        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10">
                <h2>products</h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo base_url(); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item active">
                        <strong>products</strong>
                    </li>
                </ol>
            </div>
            <div class="col-lg-2">

            </div>
        </div>
        <div class="wrapper wrapper-content  animated fadeInRight">
            <div class="ibox ">
                <div class="ibox-title">
                    <h5>Products</h5>
                    <div class="ibox-tools">
                        <span class="btn btn-primary btn-outline btn-xs" onclick="add_product();">
                            <i class="fa fa-plus"></i>
                            <span class="bold">Add</span>
                        </span>
                    </div>
                </div>
                <div class="ibox-content">
                    <table class="table table-bordered table-striped" id="products_table">
                        <thead class="bg-success">
                            <th>Name</th>
                            <th>Status</th>
                            <th>Description</th>
                            <th>Added By</th>
                            <th class="text-center" style="width:5%;">Edit</th>
                            <th class="text-center" style="width:5%;">Delete</th>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product) { ?>
                                <tr>
                                    <td><?php echo $product->title; ?></td>
                                    <td><?php echo $product->status == 1 ? '<span class="text-success">Active</span>' : '<span class="text-danger">Inactive</span>';  ?></td>
                                    <td><?php echo $product->description; ?></td>
                                    <td><?php echo $product->added_by; ?></td>
                                    <td class="text-center">
                                        <button class="btn btn-outline btn-info btn-circle" type="button" onclick="action_product('edit','<?php echo $product->product_id; ?>');">
                                            <i class="fa fa-edit" ></i>
                                        </button>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-outline btn-danger btn-circle" type="button" onclick="action_product('delete','<?php echo $product->product_id; ?>');">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal inmodal fade" id="add_product" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title">
                        <span id='model_text'>Add</span> product</h4>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo base_url('product/add_product'); ?>" id="product_form">
                            <input type="hidden" name="product_id" id="product_id">
                            <div class="checkbox p-xxs">
                                <input type="checkbox" id="status" name="status" value="1">
                                <label for="status">
                                    Active
                                </label>
                            </div>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" name="title" id="title">
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control" name="description" id="description"></textarea>
                            </div>
                        </form>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="$('#product_form').submit();">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal inmodal fade" id="delete_product" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <h4 class="modal-title">Delete product</h4>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo base_url('product/delete_product'); ?>" id="delete_product_form">
                            <input type="hidden" name="delete_product_id" id="delete_product_id">
                            <div class="alert alert-warning">
                                <strong>Warning :</strong>This action is affect in many other places and all data will be deleted after this action.
                            </div>
                            <h4 class="text-center">Are you sure you still want to delete this product ?</h4>
                        </form>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-white" data-dismiss="modal">No</button>
                        <button type="button" class="btn btn-danger" onclick="$('#delete_product_form').submit();">Yes</button>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('include/master_footer')?>
    </div>
  </div>
  
<?php $this->load->view('include/master_js');?>

<script type="text/javascript">
    $(document).ready(function(){
        $('#products_table').DataTable({
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
            ]
        });
        $("#product_form").validate ({
            rules: {
              title:{
                required : true,
              },
              description:{
                required : true,
              }
            }, 
            highlight: function(element) {
              $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
            },
            success: function(element) {
              element.closest('.form-group').removeClass('has-error').addClass('has-success');
              $(element).closest('.error').remove();
            }
        });
    });
    function action_product(action,id){
        $.ajax({
          type:'POST',   
          url: "<?php echo base_url('product/get_product_remote'); ?>",
          data: {"product_id":id},
          success: function(data){
            var json = jQuery.parseJSON(data);
            if(action=='edit'){
                $('#title').val(json.product.title);
                if(json.product.status == 1){
                    $('#status').prop('checked',true);
                }else{
                    $('#status').prop('checked',false);
                }
                $('#description').val(json.product.description);
                $('#product_id').val(json.product.id);
                $('#model_text').html('Edit '+json.product.title+" ")
                $('#add_product').modal('show');
            }else if(action=='delete'){
                $('#delete_product_id').val(json.product.id);
                $('#delete_product').modal('show');
            }
          }
        });
    }
    function add_product(){
        $('#title').val();
        $('#description').val("");
        $('#status').prop('checked',true);
        $('#product_id').val();
        $('#model_text').html("Add ");
        $('#add_product').modal('show');
    }
</script>
</body>
</html>