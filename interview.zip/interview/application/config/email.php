<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
| ------------------------------------------------------------------- 
| EMAIL CONFING 
| ------------------------------------------------------------------- 
| Configuration of outgoing mail server. 
| */
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://mail.aimtron.net';  
$config['smtp_port'] = 465;  
$config['smtp_timeout'] = '30';  
$config['smtp_user'] = 'bhavikvaghela22@gmail.com';
$config['smtp_pass'] = 'test_password';
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;
$config['newline'] = "\r\n";
$config['crlf'] = "\r\n";
/* End of file email.php */  
/* Location: ./system/application/config/email.php */