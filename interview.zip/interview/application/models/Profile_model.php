<?php 

class Profile_model extends CI_Model{		
	function __construct(){
		parent::__construct();
	}


	function saveprofile(){
		$config = array('upload_path'=>"./documents/temp",'allowed_types'=>"*");
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$profile_image=null;

		if ($this->upload->do_upload('profile_image')){
			$upload_data = $this->upload->data();
			$file_name = $upload_data['file_name'];	

			$filenamearr = explode(".", $file_name);
			$filename = $filenamearr[0];
			$filetype = $filenamearr[1];

			$this->load->helper('string');
			$random = random_string('alnum',5);
			$random1 = random_string('alnum',5);

			$profile_image = $random.'-'.$random1.".".$filetype;

			$src="./documents/temp/".$file_name;
		
			$dest='./documents/profile/'.$profile_image;
			copy($src , $dest);
			unlink($src);
		}
		$array = array(
			'name' => $this->input->post('name'),
			'username' => $this->input->post('username'), 
			'email' => $this->input->post('email'), 
			'phone' => $this->input->post('phone'),  
			'role_id' => 2,
			'profile_image' => $profile_image,
			'password' => md5($this->input->post('password')),
			'added_time' => time(),
			'added_by' => 2
		);
			$this->db->insert('user',$array);
	}	

	function update_profile(){
		$config = array('upload_path'=>"./documents/temp",'allowed_types'=>"*");
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$profile_image=null;

		if ($this->upload->do_upload('profile_image')){
			$upload_data = $this->upload->data();
			$file_name = $upload_data['file_name'];	

			$filenamearr = explode(".", $file_name);
			$filename = $filenamearr[0];
			$filetype = $filenamearr[1];

			$this->load->helper('string');
			$random = random_string('alnum',5);
			$random1 = random_string('alnum',5);

			$profile_image = $random.'-'.$random1.".".$filetype;

			$src="./documents/temp/".$file_name;
		
			$dest='./documents/profile/'.$profile_image;
			copy($src , $dest);
			unlink($src);
		}
		if($profile_image!=''){
			unlink('./documents/profile/'.$this->session->userdata('profile_image'));
		}else{
			$profile_image = $this->session->userdata('profile_image');
		}
		$array = array(
			'name' => $this->input->post('name'), 
			'phone' => $this->input->post('phone'),
			'profile_image' => $profile_image,
			'updated_by' => $this->session->userdata('id'),
			'updated_time' => time(),
		);
		$this->db->where('id',$this->session->userdata('id'))->update('user',$array);
		$this->session->set_userdata($array);
	}

	function check_login_status(){
		if($this->session->userdata('user_name')!=''){
			return true;
		}else{
			return false;
		}
	}

	function change_password(){
		$user_id = $this->session->userdata('id');
		$old_password = md5($this->input->post('old_password'));
		$this->load->model('email_model');

		$user = $this->db->select('email,username,name,password')->where('id',$user_id)->where('password',$old_password)->get('user')->row_array();
		
		if(!empty($user)){
			$array=array(
				'password'=>md5($this->input->post('new_password')),
				'added_time' => time(),
			);
			$this->db->where('id',$this->session->userdata('id'))->update('user',$array);

			/***** Email sending code *****/

			$email = $user['email'];
			$user_subject = "Change Password";
			$user_message = "Password Change ";
			$this->email_model->email_send($email,$user_subject,$user_message);

			/***** End Email sending code *****/


			$this->session->set_flashdata('success','Password change successfully !!');
			return true;
		}else{
			$this->session->set_flashdata('error','Something went wrong !!');
			return false;
		}
	}

	function get_user_data_for_forgot_password($user_email){
		return $this->db->select('email,username,name,password,forgot_key')->where('email',$user_email)->get('user')->row_array();
	}

}

?>