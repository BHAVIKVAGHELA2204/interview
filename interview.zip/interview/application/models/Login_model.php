<?php 

class Login_model extends CI_Model{		
	function __construct(){
		parent::__construct();
	}

	function do_login($username,$password){
		$user=$this->db->select('id,username,name,email,phone,profile_image')->where('username',$username)->where('password',md5($password))->get('user')->row_array();
		
		if(!empty($user)){
			$this->session->set_userdata($user);
			return true;
		}else{
			return false;
		}
	}

	function check_login_status(){
		if($this->session->userdata('username')!=''){
			return true;
		}else{
			return false;
		}
	}

	function check_forgot_key($forgot_key){
		return $this->db->select('id,name,email')->where('forgot_key',$forgot_key)->get('user')->row_array();
	}

	function check_forgot_password(){
		$user_email = $this->input->post('email');
		$user_data=$this->db->select('email,name,username')->from('user')->where('email',$this->input->post('email'))->get()->row_array();
		if(!empty($user_data)){
			$this->load->helper('string');
			$forgot_key = random_string('alnum',10).time().time().random_string('alnum',10);

			$this->db->where('email',$this->input->post('email'))->update('user',array('forgot_key'=>$forgot_key));

			$this->load->model('email_model');
			$this->load->model('profile_model');
			
			$user = $this->profile_model->get_user_data_for_forgot_password($user_email);

			/***** Email sending code *****/
	
			/*###################### forgot_pass_subject ###########################*/
			$forgot_pass_subject = "test";
			$forgot_pass_message = $forgot_key;
			$this->email_model->email_send($email,$forgot_pass_subject,$forgot_pass_message);

			$this->session->set_flashdata('success','Forgot password link is send to your email !!');
			return true;
		}else{
			$this->session->set_flashdata('error','Something went wrong !!');
			return false;
		}
	}
}

?>