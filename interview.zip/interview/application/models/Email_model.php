<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email_model extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->library('email');
	}

	function email_send($to="",$subject="",$message="",$bcc=""){
		$this->email->from('bhavikvaghela22@gamil.com','Interview')->to($to)->cc($bcc)->subject($subject)->message($message)->send();
	}
}
?>