<?php 

class Product_model extends CI_Model{		
	function __construct(){
		parent::__construct();
	}

	function get_products(){
		return $this->db->select('user.id as user_id,description,status,title,name,user.name as added_by,product.added_time as added_time,product.id as product_id')->join('user','user.id=product.added_by')->get('product')->result();
	}

	function add_product(){
		$id=$this->input->post('product_id');
		$array=array(
			'title' => $this->input->post('title'),
			'description'=>$this->input->post('description'),
			'status' => $this->input->post('status')
		);
		if($id==null){
			$array['added_by']=$this->session->userdata('id');
			$array['added_time']=time();
			$this->db->insert('product',$array);
		}else{
			$array['updated_by']=$this->session->userdata('id');
			$array['updated_time']=time();
			$this->db->where('id',$id)->update('product',$array);
		}
	}

	function get_product_remote(){
		return $this->db->select('id,title,description,status,added_time')->where('id',$_REQUEST['product_id'])->get('product')->row_array();
	}

	function delete_product(){
		$id=$this->input->post('delete_product_id');
		$this->db->where('id',$id)->delete('product');
	}
}

?>