<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('profile_model');
	}

	public function index()
	{
		$this->load->view('profile/index');
	}

	function saveprofile(){
		$this->profile_model->saveprofile();
		$this->session->set_flashdata('success','Registretion Succesfully...!');
		redirect(base_url());
	}

	function update_profile(){
		$this->profile_model->update_profile();
		$this->session->set_flashdata('success','Profile data saved successfully !!');
		redirect(base_url('home'));
	}

	function change_password(){
		$this->profile_model->change_password();
		redirect(base_url('home'));
	}
}
