<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('login_model');
	}

	public function index()
	{
		if($this->login_model->check_login_status()==true){
			redirect(base_url('home'));
		}else{
			if(isset($_POST['submit'])){
				$username=$this->input->post('username');
				$password=$this->input->post('password');
				if($this->login_model->do_login($username,$password)){
					$this->session->set_flashdata('welcome','Welcome back '.$this->session->userdata('name').' !!');
					$this->session->set_flashdata('success','Login successfully !!');
					redirect(base_url('home'));
				}else{
					$this->session->set_flashdata('error','Username or password is incorrect !!');
					redirect(base_url('login'));
				}
			}else{
				$this->load->view('login/index');
			}
		}
		
	}

	function signup(){
		$this->load->view('login/signup');
	}

	function forgot_password(){
		$this->load->view('login/forgot_password');
	}

	function check_forgot_password(){
		$this->login_model->check_forgot_password();
		redirect(base_url());
	}
	
	function logout(){
		$this->session->sess_destroy();
		$this->session->set_flashdata('success','Logout successfully !!');
		redirect(base_url());
	}
}
