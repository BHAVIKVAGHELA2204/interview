<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('product_model');
	}

	public function index(){
			$data["products"]=$this->product_model->get_products();
			$this->load->view('product/index',$data);
	}

	function add_product(){
		$this->product_model->add_product();
		$this->session->set_flashdata('success','Product added successfully !!');
		redirect(base_url('product'));
	}

	function get_product_remote(){
		$data['product']=$this->product_model->get_product_remote();
		echo json_encode($data);
	}

	function delete_product(){
		$this->product_model->delete_product();
		$this->session->set_flashdata('success','product deleted successfully !!');
		redirect(base_url('product'));
	}

}
?>